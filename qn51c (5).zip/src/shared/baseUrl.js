export const baseUrl =
  "https://my-json-server.typicode.com/awaradkar/jsonserver/";
